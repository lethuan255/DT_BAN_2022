from app.src.main.python.data.source import model_local_data_source
from app.src.main.python.data.model import Model, ModelDetails
from typing import Union


async def get_models() -> list[Model]:
    cursor = await model_local_data_source.get_models()
    models = []

    for document in cursor:
        model = Model(
            id=str(object=document['_id']),
            name=document['name'],
            created_at=document['created_at'],
        )
        models.append(model)

    return models


async def get_model_details(model_id: str) -> Union[ModelDetails, None]:
    document = await model_local_data_source.get_model_details(model_id=model_id)

    if document == None:
        return None

    return ModelDetails(
        id=str(object=document['_id']),
        name=document['name'],
        created_at=document['created_at'],
    )
