import pymongo

username = "hieubm_kma"
password = "d3jH5sWVgj3d5ioo"

uri = f'mongodb+srv://{username}:{password}@kma.u0jozlf.mongodb.net/?retryWrites=true&w=majority'
client = pymongo.MongoClient(uri)
database = client["KMA"]
