
class Model:

    def __init__(self, id: int, name: str, created_at: str):
        self.id = id
        self.name = name
        self.created_at = created_at


class ModelDetails:

    def __init__(self, id: int, name: str, created_at: str):
        self.id = id
        self.name = name
        self.source_url = f'/resources/models/{name}.h5'
        self.created_at = created_at
