from app.src.main.python.data.local import database
from pymongo.cursor import Cursor
from typing import Any, Union
from bson import ObjectId


async def get_models() -> Cursor:
    return database["models"].find({}, {"_id": 1, "name": 1, "created_at": 1})


async def get_model_details(model_id: str) -> Union[Any, None]:
    id = ObjectId(oid=model_id)
    filter = {"_id": id}

    return database["models"].find_one(filter=filter)
