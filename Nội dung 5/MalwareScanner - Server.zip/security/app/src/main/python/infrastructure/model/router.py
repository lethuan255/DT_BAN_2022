import app.src.main.python.infrastructure.model.service as service

from .schemas import Response
from fastapi import APIRouter


router = APIRouter(prefix="/models", tags=["models"])


@router.get(
    path="",
    response_model=Response,
    status_code=200
)
async def get_models():
    models = await service.get_models()

    return Response(
        message="Get models successfully",
        data=models
    )


@router.get(
    path="/{model_id}",
    response_model=Response,
    status_code=200
)
async def get_model_details(model_id: str):
    model_details = await service.get_model_details(model_id=model_id)

    return Response(
        message="Get model details successfully",
        data=model_details
    )
