import os
import fnmatch
import subprocess


def create_application_analysis(apk_file):
    return None
