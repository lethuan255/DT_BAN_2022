from pydantic import BaseModel
from typing import Any


class Application(BaseModel):
    packageName: str
    permissions: list[str] = list()


class Response(BaseModel):
    message: str
    data: Any
