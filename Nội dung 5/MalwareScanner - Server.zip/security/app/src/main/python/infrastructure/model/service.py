from app.src.main.python.data.repository import model_repository


async def get_models():
    return await model_repository.get_models()


async def get_model_details(model_id: str):
    return await model_repository.get_model_details(model_id=model_id)


async def get_model_source(model_id: str):
    return await model_repository.get_model_source(model_id=model_id)
