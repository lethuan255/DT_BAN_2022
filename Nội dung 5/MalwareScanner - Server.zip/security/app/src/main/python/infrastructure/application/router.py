import app.src.main.python.infrastructure.application.service as service

from fastapi import APIRouter, UploadFile
from .schemas import *

router = APIRouter(
    prefix="/applications",
    tags=["applications"]
)


@router.post(
    path="",
    response_model=Response,
    status_code=201
)
async def create_application_analysis(apk_file: UploadFile = None):
    if not apk_file:
        return Response(
            message="No APK files have been attached.",
            data=None
        )

    analysis = service.create_application_analysis(apk_file=apk_file)

    return Response(
        message="Create application's analysis has successful.",
        data=analysis
    )
