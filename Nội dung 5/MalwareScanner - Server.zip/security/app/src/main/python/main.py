from .infrastructure import *
from fastapi import FastAPI


server = FastAPI(title="KMA - Security", version="1.0.0")


server.include_router(model_router, prefix="/api/v1")
