import os
import json
import numpy as np


def extract(analysis):
    fields: list[str] = extract_fields(analysis=analysis)

    labels_path = os.path.join("model", "labels.json")
    labels = get_data_from_json(file_path=labels_path)
    records = []

    for apk_analysis in analysis:
        type = labels[apk_analysis["type"]]
        permissions = map(lambda permission: permission.split(".")[-1].upper(), apk_analysis["permissions"])
        permissions = set(permissions)
        apis = [api for api in apk_analysis["apis"]]
        record = []

        record.append(type)
        for field in fields[1:]:
            if field in permissions or field in apis:
                record.append(1)
            else:
                record.append(0)
        records.append(record)


def get_data_from_json(file_path):
    with open(file_path, "rb") as fp:
        data = json.load(fp=fp)
    return data


def extract_fields(analysis):
    permissions = set()
    apis = {}

    for apk_analysis in analysis:
        apk_permissions = [permission.split(".")[-1].upper() for permission in apk_analysis["permissions"]]
        apk_apis = apk_analysis["apis"]

        permissions.update(apk_permissions)
        for api in apk_apis:
            frequency = apk_apis[api]["frequency"]
            if api in apis:
                apis[api] += frequency
            else:
                apis[api] = frequency

    permissions = sorted(permissions)
    keys = list(apis.keys())
    values = list(apis.values())
    sorted_value_index = np.argsort(values)[::-1][:1000]
    apis = {keys[i]: values[i] for i in sorted_value_index}
    return ["Label", *permissions, *list(apis.keys())]
