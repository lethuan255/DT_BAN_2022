import os
import fnmatch
import subprocess
import re

from androguard.core.bytecodes.apk import APK
from collections import OrderedDict


def preprocess(apks):
    analysis = []

    for path in apks:
        try:
            apk = APK(path)
        except Exception as e:
            print("Error in APK:", path, "->", e)
            continue

        apk_analysis = OrderedDict()

        apk_analysis["package"] = apk.get_package()
        apk_analysis["type"] = path.split(sep="/")[:-1][-1]
        apk_analysis["permissions"] = apk.get_permissions()
        apk_analysis["apis"] = analyze(apk=apk)

        analysis.append(apk_analysis)


def analyze(apk):
    packages = get_content("data/packages.txt")
    packages = [x.decode().replace('\n', '') for x in packages]

    classes = get_content("data/classes.txt")
    classes = [x.decode().replace('\n', '') for x in classes]

    out_dir = "out/" + apk.replace(".apk", "/")
    features = {}

    decode(apk=apk, out=out_dir)
    for root, dirs, files, in os.walk(out_dir):
        for file in fnmatch.filter(files, "*.smali"):
            path = os.path.join(root, file)

            with open(path) as f:
                content = f.readlines()
            content = [x.strip() for x in content]

            # Searching for API calls
            content = [x for x in content if 'invoke-' in x or 'invoke-virtual' in x or 'invoke-direct' in x]

            for line in content:
                # Remove commands between brackets (invoke)
                line = re.sub("\{[^]]*\}", lambda x: x.group(0).replace(',', ''), line)
                line_contents = re.split(', |;->', line)

                if len(line_contents) != 2:
                    try:
                        package = line_contents[1]
                        method = line_contents[2]
                    except IndexError:
                        pass
                else:
                    package = "Object"
                    method = line_contents[1]

                if package.startswith("L"):
                    package = package[1:]

                package = package.split("/")
                _class = package[-1]
                del package[-1]
                package = '.'.join(package)
                method = method.split('(')[0]

                if package in packages and _class in classes and method != '<init>':
                    api = package + '.' + _class + '.' + method

                    if api in features:
                        features[api] += 1
                    else:
                        features[api] = 1
    return features


def get_content(file_path):
    with open(file_path, 'rb') as fp:
        content = fp.readlines()
    return content


def decode(apk, out):
    if not os.path.exists(out):
        command = "java -jar libs/apktool/apktool.jar d " + apk + " -f --force-manifest --no-assets -o " + out + " -r"
        popen = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)

        popen.communicate()
