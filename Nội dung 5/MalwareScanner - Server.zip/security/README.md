<!-- TABLE OF CONTENTS -->

# 📗 Table of Contents

- [📖 About the Project](#about-project)
  - [🛠 Built With](#built-with)
    - [Tech Stack](#tech-stack)
    - [Key Features](#key-features)
  - [🚀 Live Demo](#live-demo)
- [💻 Getting Started](#getting-started)
  - [Prerequisites](#prerequisites)
  - [Setup](#setup)
  - [Install](#install)
  - [Usage](#usage)
  - [Deployment](#triangular_flag_on_post-deployment)

<!-- PROJECT DESCRIPTION -->

# 📖 Malware Scanner <a name="about-project"></a>

> Describe project in 1 or 2 sentences.

</br>

## 🛠 Built With <a name="built-with"></a>

### Tech Stack <a name="tech-stack"></a>

> Describe the tech stack and include only the relevant sections that apply to your project.

<!-- Features -->

### Key Features <a name="key-features"></a>

> Describe between 1-3 key features of the application.

<!-- LIVE DEMO -->

## 🚀 Live Demo <a name="live-demo"></a>

> Add a link to deployed project.

</br>

<!-- GETTING STARTED -->

## 💻 Getting Started <a name="getting-started"></a>

> Describe how a new developer could make use of project.

To get a local copy up and running, follow these steps.

### 1. Prerequisites

In order to run this project you need:

- Python 3.9

### 2. Setup

- Clone this repository to your desired folder.

- Create Virtual Environment

  > A virtual environment is a Python tool for dependency management and project isolation. This means that each project can have any package installed locally in an isolated directory instead of being installed globally.

  Install Python virtual environment package.

  ```sh
  $ sudo apt update

  $ sudo apt install python3-venv
  ```

  Create a Python virtual environment for your project.

  ```sh
  $ python3 -m venv venv
  ```

### 3. Install

- Enter the virtual environment.

  ```sh
  $ source venv/bin/activate
  ```

- Install dependencies

  ```sh
  (venv) $ pip install -r requirements.txt
  ```

### 4. Usage

To run the project, execute the following command:

```sh
$ uvicorn app.src.main.python.main:server --reload
```

### 5. Deployment

You can deploy this project by following these steps:

- Install the gunicorn Python package.

  ```sh
  (venv) $ pip install gunicorn
  ```

- Create Systemd Service

  - Create and edit systemd unit file.

    ```sh
    $ sudo nano /etc/systemd/system/kma.security.service
    ```

  - Paste the following code and save the file.

    ```
    [Unit]
    Description=Gunicorn Daemon for Security Application
    After=network.target

    [Service]
    User=kma
    Group=www-data
    WorkingDirectory=/home/kma/Applications/Security
    ExecStart=/home/kma/Applications/Security/venv/bin/gunicorn src.main:app

    [Install]
    WantedBy=multi-user.target
    ```

  - Start & enable the service.

    ```sh
    $ sudo systemctl start kma.security

    $ sudo systemctl enable kma.security
    ```

    To verify if everything works run the following command.

    ```sh
    $ sudo systemctl status kma.security
    ```

    Expected output:

    ```
    ● kma.security.service - Gunicorn Daemon for KMA Security Application
     Loaded: loaded (/etc/systemd/system/kma.security.service; enabled; vendor preset: enabled)
     Active: active (running) since Sun 2023-01-08 20:45:55 +07; 7min ago
    Main PID: 3663 (gunicorn)
      Tasks: 4 (limit: 4577)
     Memory: 61.9M
     CGroup: /system.slice/kma.security.service
             ├─3663 /home/bmhieu/Applications/Security/venv/bin/python3 /home/bmhieu/Applications/Security/venv/bin/gunicorn src.main:app
             ├─3665 /home/bmhieu/Applications/Security/venv/bin/python3 /home/bmhieu/Applications/Security/venv/bin/gunicorn src.main:app
             ├─3666 /home/bmhieu/Applications/Security/venv/bin/python3 /home/bmhieu/Applications/Security/venv/bin/gunicorn src.main:app
             └─3667 /home/bmhieu/Applications/Security/venv/bin/python3 /home/bmhieu/Applications/Security/venv/bin/gunicorn src.main:app

    Jan 08 20:45:55 ubuntu systemd[1]: Started Gunicorn Daemon for KMA Security Application.
    ```

    Also, you can check the response using the following command.

    ```sh
    $ curl http://0.0.0.0:8000
    ```

- Setup Nginx as Reverse Proxy

  - Install Nginx

    ```sh
    $ sudo apt install nginx
    ```

  - Add vhost configuration

    Add vhost file to _`sites-available`_ directory.

    ```sh
    $ sudo nano /etc/nginx/sites-available/kma.security.com.conf
    ```

    Paste the following content (replace _your_domain_ with your actual domain) and save the file

    ```
    server {
      listen 80;
      server_name your_domain www.your_domain;

      location / {
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header Host $http_host;
        proxy_pass http://0.0.0.0:8000;
        proxy_redirect off;
        client_max_body_size 100M;
      }

      proxy_read_timeout 30;
      proxy_connect_timeout 30;
      proxy_send_timeout 30;
    }
    ```

  - Activate vhost configuration

    Add a soft link of the vhost file in the _`sites-enabled`_ directory.

    ```sh
    $ sudo ln -s /etc/nginx/sites-available/kma.security.com.conf /etc/nginx/sites-enabled/
    ```

  - Test and reload the configuration

    Test the configuration.

    ```sh
    $ sudo nginx -t
    ```

    Expected output:

    ```
    nginx: the configuration file /etc/nginx/nginx.conf syntax is ok

    nginx: configuration file /etc/nginx/nginx.conf test is successful
    ```

    Reload Nginx.

    ```sh
    $ sudo systemctl reload nginx
    ```

- Secure Nginx with an SSL Certificate
