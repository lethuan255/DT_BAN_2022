from multiprocessing import cpu_count

# HTTP Path
bind = "0.0.0.0:8000"

# Worker Options
workers = cpu_count() + 1
worker_class = 'uvicorn.workers.UvicornWorker'

# Logging Options
loglevel = 'debug'
accesslog = './logs/access.log'
errorlog = './logs/error.log'
